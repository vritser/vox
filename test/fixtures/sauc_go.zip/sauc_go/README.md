Howto
=====

## 运行

### 调用流式语音识别 SAUC

#### 新版控制台鉴权（X-Api-Key）
```
go run . \
--url=wss://openspeech.bytedance.com/api/v3/sauc/bigmodel_nostream \
--file=<audio_file_path> \
--resource_id=volc.bigasr.sauc.duration \
--api_key=<api_key>
```

#### 老版控制台鉴权（App-Key + Access-Key）
```
go run . \
--url=wss://openspeech.bytedance.com/api/v3/sauc/bigmodel_nostream \
--file=<audio_file_path> \
--resource_id=volc.bigasr.sauc.duration \
--app_key=<app_id> \
--access_key=<access_key>
```

也可在 `../config.toml` 中配置鉴权信息（命令行参数优先）：

```toml
[auth]
# 新版控制台
api_key = "xxxxx"

# 或老版控制台
app_key = "xxxxx"
access_key = "xxxxxxxxxxxxxxxx"

# 可选
# resource_id = "volc.bigasr.sauc.duration"
```
