package main

import (
	"context"
	"flag"
	"log"
	"os"
	"sync"

	"byted.org/data-speech/asr-tob-demo/sauc/protocol"
	"github.com/bytedance/sonic"
)

var (
	filePath        = flag.String("file", "eng_ddc_itn.wav", "audio file path")
	wsURL           = flag.String("url", "wss://openspeech.bytedance.com/api/v3/sauc/bigmodel_async", "request url")
	segmentDuration = flag.Int("seg_duration", 200, "audio duration(ms) per packet, default:200")
	apiKey          = flag.String("api_key", "", "API key for authorization (new console auth, X-Api-Key)")
	appKey          = flag.String("app_key", "", "App key (legacy console auth, used with access_key)")
	accessKey       = flag.String("access_key", "", "Access key for authorization (legacy console auth, used with app_key)")
	resourceID      = flag.String("resource_id", "volc.seedasr.sauc.duration", "X-Api-Resource-Id")
)

func main() {
	flag.Parse()
	log.SetFlags(log.Lmicroseconds | log.Lshortfile)

	if *apiKey != "" {
		_ = os.Setenv("API_KEY", *apiKey)
	}
	if *appKey != "" {
		_ = os.Setenv("APP_KEY", *appKey)
	}
	if *accessKey != "" {
		_ = os.Setenv("ACCESS_KEY", *accessKey)
	}
	if *resourceID != "" {
		_ = os.Setenv("RESOURCE_ID", *resourceID)
	}

	if protocol.ApiKey() == "" && (protocol.AppKey() == "" || protocol.AccessKey() == "") {
		log.Fatal("auth required: provide --api_key, or --app_key + --access_key, or set them in ../config.toml")
	}
	// 打开日志文件，如果文件不存在则创建
	file, err := os.OpenFile("run.log", os.O_CREATE|os.O_WRONLY|os.O_APPEND|os.O_TRUNC, 0666)
	if err != nil {
		log.Fatalf("Failed to open log file: %v", err)
	}
	defer func() {
		_ = file.Close()
	}()
	run()
}

func run() {
	payload := protocol.AsrRequestPayload{
		User: protocol.UserMeta{
			Uid: "demo_uid",
		},
		Audio: protocol.AudioMeta{
			Format:  "wav",
			Codec:   "raw",
			Rate:    16000,
			Bits:    16,
			Channel: 1,
		},
		Request: protocol.RequestMeta{
			ModelName:       "bigmodel",
			EnableITN:       true,
			EnablePUNC:      true,
			EnableDDC:       true,
			ShowUtterances:  true,
			EnableNonstream: true,
		},
	}
	c := protocol.NewAsrWsClient(*wsURL, *segmentDuration)
	resChan := make(chan *protocol.AsrResponse)
	wg := sync.WaitGroup{}
	wg.Add(1)
	go func() {
		for res := range resChan {
			resStr, _ := sonic.MarshalString(res)
			log.Println(resStr)
		}
		wg.Done()
	}()

	err := c.Execute(context.Background(), *filePath, resChan, payload)
	if err != nil {
		log.Fatalf("failed to execute: %v", err)
		return
	}
	wg.Wait()
}
